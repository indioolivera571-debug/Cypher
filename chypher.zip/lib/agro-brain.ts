// Chypher - motor agronómico local (sin backend, sin costo).
// Interpreta la consulta del usuario y devuelve una respuesta:
// primero intenta resolver cálculos técnicos, luego busca en la base de conocimiento.

export type AgroReply = {
  text: string
  kind: "calc" | "knowledge" | "fallback"
}

// ---------- utilidades ----------

function normalize(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // quita tildes
    .trim()
}

// Extrae todos los números (admite coma o punto decimal) de un texto.
function numbers(s: string): number[] {
  const matches = s.replace(/,/g, ".").match(/\d+(\.\d+)?/g)
  return matches ? matches.map(Number) : []
}

function round(n: number, d = 2): number {
  const f = 10 ** d
  return Math.round(n * f) / f
}

// ---------- cálculos técnicos ----------

type Calculator = {
  id: string
  test: (n: string) => boolean
  run: (raw: string, norm: string) => string | null
}

const calculators: Calculator[] = [
  // Dosis de fertilizante a partir de nutriente objetivo y concentración
  {
    id: "dosis-fertilizante",
    test: (n) =>
      /(dosis|cuant[oa]|calcul).*(fertiliz|urea|fosfato|nitrogen|potasi|fosfor|nutriente)/.test(n) ||
      /(urea|nitrogeno|fosfato|superfosfato).*(kg|hectarea|ha|aplicar)/.test(n),
    run: (_raw, norm) => {
      const nums = numbers(norm)
      // objetivo de nutriente (kg/ha) y % de concentración
      const pctMatch = norm.match(/(\d+(\.\d+)?)\s*(%|por ?ciento)/)
      const pct = pctMatch ? Number(pctMatch[1].replace(",", ".")) : undefined
      // asumimos urea 46% si menciona urea y no da %
      const isUrea = /urea/.test(norm)
      const conc = pct ?? (isUrea ? 46 : undefined)
      const target = nums.find((v) => v >= 10 && v <= 500) // kg/ha de nutriente razonable
      if (!conc || target === undefined) return null
      const dose = round((target * 100) / conc, 1)
      const fuente = isUrea ? "urea" : "el fertilizante"
      return [
        `Cálculo de dosis de fertilizante`,
        ``,
        `• Nutriente objetivo: ${target} kg/ha`,
        `• Concentración de ${fuente}: ${conc}%`,
        ``,
        `Dosis = (${target} × 100) ÷ ${conc} = ${dose} kg/ha de producto comercial.`,
        ``,
        `Es decir, aplicá aproximadamente ${dose} kg/ha de ${fuente} para aportar ${target} kg/ha del nutriente.`,
      ].join("\n")
    },
  },

  // Densidad de siembra -> plantas objetivo, distancia entre hileras
  {
    id: "densidad-siembra",
    test: (n) => /(densidad|plantas|semillas).*(siembra|sembrar|hectarea|ha|hilera|surco)/.test(n) ||
      /(sembrar|siembra).*(plantas|densidad)/.test(n),
    run: (_raw, norm) => {
      const nums = numbers(norm)
      // plantas/ha (buscamos un número grande, admite "mil")
      let plants = nums.find((v) => v >= 1000)
      if (!plants) {
        const milMatch = norm.match(/(\d+(\.\d+)?)\s*mil/)
        if (milMatch) plants = Number(milMatch[1].replace(",", ".")) * 1000
      }
      // distancia entre hileras en metros (0.2 - 1.05)
      const rowMatch = norm.match(/(\d+(\.\d+)?)\s*(m|metros|cm)\s*(entre)?\s*(hilera|surco|linea)/)
      let row = rowMatch ? Number(rowMatch[1].replace(",", ".")) : 0.52
      if (rowMatch && /cm/.test(rowMatch[3])) row = row / 100
      if (!plants) return null
      // germinación asumida 90%
      const germ = 0.9
      const seedsPerHa = Math.round(plants / germ)
      const perMeterRow = round((plants * row) / 10000, 2) // plantas por metro lineal
      return [
        `Cálculo de densidad de siembra`,
        ``,
        `• Población objetivo: ${plants.toLocaleString("es-AR")} plantas/ha`,
        `• Distancia entre hileras: ${row} m`,
        `• Germinación estimada: ${germ * 100}%`,
        ``,
        `Semillas a sembrar = ${plants.toLocaleString("es-AR")} ÷ 0,90 = ${seedsPerHa.toLocaleString("es-AR")} semillas/ha.`,
        `Plantas por metro lineal = ${perMeterRow} pl/m.`,
        ``,
        `Ajustá la germinación según el poder germinativo real del lote de semilla.`,
      ].join("\n")
    },
  },

  // Carga animal (EV/ha)
  {
    id: "carga-animal",
    test: (n) => /(carga animal|equivalente vaca|ev\/ha|ev por ha|cuantos animales|receptividad)/.test(n),
    run: (_raw, norm) => {
      const nums = numbers(norm)
      // superficie (ha) y cantidad de EV
      const haMatch = norm.match(/(\d+(\.\d+)?)\s*(ha|hectarea)/)
      const evMatch = norm.match(/(\d+(\.\d+)?)\s*(ev|equivalente|cabezas|animales|vacas)/)
      const ha = haMatch ? Number(haMatch[1].replace(",", ".")) : undefined
      const ev = evMatch ? Number(evMatch[1].replace(",", ".")) : undefined
      if (ha && ev) {
        const carga = round(ev / ha, 2)
        return [
          `Cálculo de carga animal`,
          ``,
          `• Equivalentes vaca (EV): ${ev}`,
          `• Superficie: ${ha} ha`,
          ``,
          `Carga = ${ev} EV ÷ ${ha} ha = ${carga} EV/ha.`,
          ``,
          `Recordá que 1 EV equivale a una vaca de 400 kg que gesta y cría un ternero hasta el destete (requiere ~ 3.100 kg de MS/año).`,
        ].join("\n")
      }
      return [
        `Carga animal (EV/ha)`,
        ``,
        `La carga animal se calcula como: EV totales ÷ superficie (ha).`,
        `1 Equivalente Vaca (EV) = vaca de 400 kg que cría un ternero al destete.`,
        ``,
        `Decime cuántos EV tenés y la superficie del potrero y te doy el valor exacto.`,
      ].join("\n")
    },
  },

  // Regla general: kg totales a partir de dosis kg/ha y superficie
  {
    id: "total-por-superficie",
    test: (n) => /(cuant[oa]s? kg|cuanto necesito|total).*(hectarea|ha)/.test(n) && /(dosis|kg\/ha|kg por ha)/.test(n),
    run: (_raw, norm) => {
      const doseMatch = norm.match(/(\d+(\.\d+)?)\s*(kg\/ha|kg por ha|kg\/hectarea)/)
      const haMatch = norm.match(/(\d+(\.\d+)?)\s*(ha|hectarea)/)
      const dose = doseMatch ? Number(doseMatch[1].replace(",", ".")) : undefined
      const ha = haMatch ? Number(haMatch[1].replace(",", ".")) : undefined
      if (!dose || !ha) return null
      return [
        `Cantidad total de insumo`,
        ``,
        `Total = ${dose} kg/ha × ${ha} ha = ${round(dose * ha, 1)} kg.`,
      ].join("\n")
    },
  },
]

// ---------- base de conocimiento ----------

type Topic = {
  id: string
  keywords: string[]
  answer: string
}

const topics: Topic[] = [
  {
    id: "cic",
    keywords: ["capacidad de intercambio cationico", "cic", "intercambio cationico"],
    answer:
      "La Capacidad de Intercambio Catiónico (CIC) es la cantidad de cationes (Ca²⁺, Mg²⁺, K⁺, Na⁺, H⁺, Al³⁺) que un suelo puede retener e intercambiar en su complejo coloidal (arcillas y materia orgánica). Se expresa en cmol(+)/kg (o meq/100 g).\n\nUna CIC alta indica mayor capacidad de retener nutrientes y agua, y mayor poder amortiguador frente a cambios de pH. Suelos arcillosos y ricos en materia orgánica tienen CIC alta; los arenosos, baja. Es clave para decidir la estrategia de fertilización y encalado.",
  },
  {
    id: "ph-suelo",
    keywords: ["ph del suelo", "acidez del suelo", "ph suelo", "encalado", "cal agricola"],
    answer:
      "El pH del suelo mide su acidez o alcalinidad y controla la disponibilidad de nutrientes.\n\n• pH < 5,5: suelo ácido — puede haber toxicidad por Al y Mn, y menor disponibilidad de P, Ca, Mg. Se corrige con encalado.\n• pH 6,0–7,0: rango óptimo para la mayoría de los cultivos.\n• pH > 7,5: alcalino — puede limitar la disponibilidad de P, Fe, Zn, Mn.\n\nEl encalado (carbonato de calcio) sube el pH; el yeso mejora suelos sódicos sin cambiar mucho el pH.",
  },
  {
    id: "materia-organica",
    keywords: ["materia organica", "humus", "carbono del suelo", "mo del suelo"],
    answer:
      "La materia orgánica (MO) del suelo es el conjunto de residuos vegetales y animales en distintos grados de descomposición, más el humus estable. Aporta:\n\n• Nutrientes por mineralización (N, P, S).\n• Mejora estructura, infiltración y retención de agua.\n• Aumenta la CIC y la actividad biológica.\n\nSe mantiene con rotaciones, cultivos de cobertura, reposición de rastrojos y siembra directa. Un descenso de MO indica degradación del suelo.",
  },
  {
    id: "textura",
    keywords: ["textura del suelo", "arcilla", "arena", "limo", "triangulo textural"],
    answer:
      "La textura del suelo es la proporción de arena, limo y arcilla. Se clasifica con el triángulo textural.\n\n• Arenosos: buen drenaje, baja retención de agua y nutrientes.\n• Arcillosos: alta retención de agua y nutrientes, pero drenaje lento y riesgo de compactación.\n• Francos: equilibrio ideal entre los tres, los más productivos.\n\nLa textura condiciona el riego, la fertilización y el laboreo.",
  },
  {
    id: "nutrientes",
    keywords: ["nutrientes de las plantas", "macronutrientes", "micronutrientes", "npk", "deficiencia de nutrientes"],
    answer:
      "Los nutrientes esenciales se dividen en:\n\n• Macronutrientes primarios: N (crecimiento/proteínas), P (energía/raíces), K (regulación hídrica/calidad).\n• Secundarios: Ca, Mg, S.\n• Micronutrientes: Fe, Mn, Zn, Cu, B, Mo, Cl.\n\nEl N deficiente da clorosis en hojas viejas; el P, tonos violáceos; el K, necrosis en bordes. El diagnóstico se hace con análisis de suelo y foliar.",
  },
  {
    id: "rotacion",
    keywords: ["rotacion de cultivos", "rotacion", "secuencia de cultivos"],
    answer:
      "La rotación de cultivos es la sucesión planificada de especies en un mismo lote a lo largo del tiempo. Beneficios:\n\n• Corta ciclos de plagas, malezas y enfermedades.\n• Mejora la fertilidad (ej. leguminosas fijan N).\n• Diversifica raíces y aporta rastrojos de distinta relación C/N.\n\nUn ejemplo pampeano típico: soja – maíz – trigo/soja de segunda, intercalando cultivos de cobertura.",
  },
  {
    id: "siembra-directa",
    keywords: ["siembra directa", "labranza cero", "no laboreo"],
    answer:
      "La siembra directa consiste en sembrar sin remover el suelo, sobre el rastrojo del cultivo anterior. Ventajas:\n\n• Reduce la erosión hídrica y eólica.\n• Conserva humedad y materia orgánica.\n• Menor consumo de combustible y pasadas.\n\nRequiere buen manejo de malezas (control químico o cultivos de cobertura) y rotación para evitar compactación y patógenos.",
  },
  {
    id: "cultivos-cobertura",
    keywords: ["cultivos de cobertura", "cobertura", "abono verde", "servicios ecosistemicos"],
    answer:
      "Los cultivos de cobertura (o de servicio) se siembran entre cultivos de renta para cubrir el suelo. Aportan:\n\n• Control de malezas por competencia.\n• Aporte de carbono y, si son leguminosas, fijación de N.\n• Reducción de erosión y mejora de infiltración.\n\nEjemplos: vicia, centeno, avena, raigrás. Se los seca (químico o rolado) antes del cultivo siguiente.",
  },
  {
    id: "ganaderia-ev",
    keywords: ["equivalente vaca", "ev", "receptividad", "pastoreo", "rotativo"],
    answer:
      "En ganadería, el Equivalente Vaca (EV) es la unidad de referencia: una vaca de 400 kg que gesta y cría un ternero hasta el destete, consumiendo ~3.100 kg de materia seca por año.\n\nLa receptividad de un potrero (EV/ha) surge de comparar la oferta forrajera con ese requerimiento. El pastoreo rotativo divide el campo en parcelas para dar descanso y mejorar el aprovechamiento del forraje.",
  },
  {
    id: "riego",
    keywords: ["riego", "lamina de riego", "evapotranspiracion", "necesidad de agua"],
    answer:
      "El riego busca reponer el agua que el cultivo consume por evapotranspiración (ETc). ETc = ET0 × Kc, donde ET0 es la evapotranspiración de referencia y Kc el coeficiente del cultivo según su etapa.\n\nLa lámina de riego se ajusta a la capacidad de campo del suelo y su textura. Sistemas: gravedad, aspersión y goteo (el más eficiente). Regar en exceso lava nutrientes y compacta.",
  },
]

const GREETING_KEYWORDS = ["hola", "buenas", "buen dia", "que tal", "como estas", "chypher"]

// ---------- router principal ----------

export function answer(userText: string): AgroReply {
  const norm = normalize(userText)

  // 1) intentar cálculos
  for (const c of calculators) {
    if (c.test(norm)) {
      const result = c.run(userText, norm)
      if (result) return { text: result, kind: "calc" }
    }
  }

  // 2) base de conocimiento (por coincidencia de keywords)
  let best: { topic: Topic; score: number } | null = null
  for (const t of topics) {
    let score = 0
    for (const kw of t.keywords) {
      if (norm.includes(kw)) score += kw.split(" ").length // frases largas pesan más
    }
    if (score > 0 && (!best || score > best.score)) best = { topic: t, score }
  }
  if (best) return { text: best.topic.answer, kind: "knowledge" }

  // 3) saludo
  if (GREETING_KEYWORDS.some((k) => norm.includes(k)) && norm.length < 40) {
    return {
      text: "¡Hola! Contame qué necesitás: puedo explicarte temas de suelos, cultivos, ganadería o resolver un cálculo (dosis de fertilizante, densidad de siembra, carga animal).",
      kind: "knowledge",
    }
  }

  // 4) fallback
  return {
    text: [
      "Todavía no tengo una respuesta específica para eso, pero puedo ayudarte con:",
      "",
      "• Suelos: CIC, pH y encalado, materia orgánica, textura, nutrientes.",
      "• Cultivos: rotación, siembra directa, cultivos de cobertura, riego.",
      "• Ganadería: equivalente vaca, receptividad, pastoreo.",
      "• Cálculos: dosis de fertilizante, densidad de siembra, carga animal.",
      "",
      "Probá reformulando tu consulta con alguno de esos temas.",
    ].join("\n"),
    kind: "fallback",
  }
}

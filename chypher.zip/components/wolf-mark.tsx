import { cn } from "@/lib/utils"

export function WolfMark({
  className,
  state = "idle",
}: {
  className?: string
  state?: "idle" | "listening" | "thinking" | "speaking"
}) {
  return (
    <svg
      viewBox="0 0 192 192"
      className={cn("select-none", className)}
      role="img"
      aria-label="Chypher, mascota lobo"
    >
      <g transform="translate(96,96)">
        <ellipse cx="0" cy="8" rx="45" ry="50" fill="var(--color-primary)" />
        <ellipse
          cx="-28"
          cy="-25"
          rx="18"
          ry="28"
          fill="var(--color-primary)"
          transform="rotate(-25 -28 -25)"
        />
        <ellipse
          cx="28"
          cy="-25"
          rx="18"
          ry="28"
          fill="var(--color-primary)"
          transform="rotate(25 28 -25)"
        />
        <path
          d="M-55 -45 Q-48 -55 -38 -48"
          fill="var(--color-foreground)"
          stroke="var(--color-accent)"
          strokeWidth="2"
        />
        <circle cx="-12" cy="0" r="8" fill="#241b08" />
        <circle cx="12" cy="0" r="8" fill="#241b08" />
        <circle
          cx="-10"
          cy="1"
          r="4"
          fill="var(--color-foreground)"
          className={state === "thinking" ? "animate-pulse" : undefined}
        />
        <circle
          cx="14"
          cy="1"
          r="4"
          fill="var(--color-foreground)"
          className={state === "thinking" ? "animate-pulse" : undefined}
        />
        <ellipse cx="0" cy="15" rx="6" ry="8" fill="#241b08" />
        <path
          d="M-6 22 Q0 28 6 22"
          stroke="#241b08"
          strokeWidth="1.5"
          fill="none"
        />
        <path
          d="M-8 24 L-12 32 M0 28 L0 36 M8 24 L12 32"
          stroke="var(--color-accent)"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
      </g>
    </svg>
  )
}

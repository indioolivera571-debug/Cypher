"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { Mic, Square, Volume2, VolumeX, Send, Sprout, Ruler, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { useSpeech } from "@/hooks/use-speech"
import { WolfMark } from "@/components/wolf-mark"
import { answer } from "@/lib/agro-brain"

type Message = {
  id: string
  role: "user" | "assistant"
  content: string
}

const SUGGESTIONS = [
  { icon: Sprout, label: "Suelos", prompt: "Explicame qué es la capacidad de intercambio catiónico del suelo." },
  { icon: Ruler, label: "Cálculo de dosis", prompt: "Calculá la dosis para aplicar 120 kg de nitrógeno por hectárea usando urea al 46 por ciento." },
  { icon: Sprout, label: "Densidad de siembra", prompt: "Ayudame a calcular la densidad de siembra de maíz para lograr 75 mil plantas por hectárea." },
  { icon: Ruler, label: "Carga animal", prompt: "Cómo calculo la carga animal en equivalentes vaca por hectárea." },
]

const GREETING =
  "¡Hola! Soy Chypher, tu asistente agronómico. Preguntame sobre suelos, cultivos, ganadería o pedime un cálculo técnico. Podés hablarme tocando el micrófono."

export function ChypherAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    { id: "greeting", role: "assistant", content: GREETING },
  ])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [ttsEnabled, setTtsEnabled] = useState(true)

  const { supported, listening, speaking, interim, startListening, stopListening, speak, stopSpeaking } =
    useSpeech("es-AR")

  const scrollRef = useRef<HTMLDivElement>(null)
  const initializedRef = useRef(false)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" })
  }, [messages, interim, loading])

  const sendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim()
      if (!trimmed || loading) return

      stopSpeaking()
      const userMessage: Message = { id: crypto.randomUUID(), role: "user", content: trimmed }
      setMessages((prev) => [...prev, userMessage])
      setInput("")
      setLoading(true)

      // Respuesta 100% local (base de conocimiento + cálculos), sin backend ni costo.
      const { text: reply } = answer(trimmed)
      // Pequeña demora para que se perciba la respuesta y se vea el estado "pensando".
      window.setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          { id: crypto.randomUUID(), role: "assistant", content: reply },
        ])
        if (ttsEnabled) speak(reply)
        setLoading(false)
      }, 350)
    },
    [loading, speak, stopSpeaking, ttsEnabled],
  )

  // Handle deep-link shortcuts from the PWA manifest (?q=suelos / ?q=calcular).
  useEffect(() => {
    if (initializedRef.current) return
    initializedRef.current = true
    const q = new URLSearchParams(window.location.search).get("q")
    if (q === "suelos") setInput(SUGGESTIONS[0].prompt)
    else if (q === "calcular") setInput(SUGGESTIONS[1].prompt)
  }, [])

  const handleMic = () => {
    if (listening) {
      stopListening()
      return
    }
    stopSpeaking()
    startListening((finalText) => sendMessage(finalText))
  }

  const state = listening ? "listening" : loading ? "thinking" : speaking ? "speaking" : "idle"

  return (
    <div className="flex min-h-dvh flex-col bg-background">
      {/* Header */}
      <header className="flex items-center gap-3 border-b border-border px-4 py-3">
        <WolfMark className="h-10 w-10 shrink-0" state={state} />
        <div className="min-w-0 flex-1">
          <h1 className="font-sans text-lg font-bold leading-tight text-foreground">Chypher</h1>
          <p className="truncate text-xs text-muted-foreground">Asistente agronómico · astuto como un lobo</p>
        </div>
        <button
          type="button"
          onClick={() => {
            if (speaking) stopSpeaking()
            setTtsEnabled((v) => !v)
          }}
          aria-label={ttsEnabled ? "Silenciar voz" : "Activar voz"}
          className={cn(
            "flex h-9 w-9 items-center justify-center rounded-full border border-border transition-colors",
            ttsEnabled ? "bg-secondary text-accent" : "bg-transparent text-muted-foreground",
          )}
        >
          {ttsEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
        </button>
      </header>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4">
        <div className="mx-auto flex w-full max-w-2xl flex-col gap-3">
          {messages.map((m) => (
            <MessageBubble key={m.id} role={m.role} content={m.content} />
          ))}

          {listening && interim && (
            <div className="self-end rounded-2xl rounded-br-md bg-primary/20 px-4 py-2.5 text-sm text-foreground/70 italic">
              {interim}
            </div>
          )}

          {loading && (
            <div className="flex items-center gap-2 self-start rounded-2xl rounded-bl-md bg-card px-4 py-3 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin text-primary" />
              Pensando...
            </div>
          )}

          {messages.length <= 1 && !loading && (
            <div className="mt-2 grid grid-cols-2 gap-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s.label}
                  type="button"
                  onClick={() => sendMessage(s.prompt)}
                  className="flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-3 text-left text-sm text-foreground transition-colors hover:border-primary hover:bg-secondary"
                >
                  <s.icon className="h-4 w-4 shrink-0 text-primary" />
                  <span className="leading-tight">{s.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Composer */}
      <footer className="border-t border-border bg-background px-4 pb-6 pt-3">
        <div className="mx-auto flex w-full max-w-2xl items-end gap-2">
          <button
            type="button"
            onClick={handleMic}
            disabled={!supported}
            aria-label={listening ? "Detener grabación" : "Hablar"}
            className={cn(
              "relative flex h-12 w-12 shrink-0 items-center justify-center rounded-full transition-colors disabled:opacity-40",
              listening ? "bg-accent text-accent-foreground" : "bg-primary text-primary-foreground",
            )}
          >
            {listening && (
              <span className="absolute inset-0 animate-ping rounded-full bg-accent/60" aria-hidden />
            )}
            {listening ? <Square className="relative h-5 w-5" /> : <Mic className="relative h-5 w-5" />}
          </button>

          <div className="flex flex-1 items-end rounded-2xl border border-border bg-input px-3 py-1.5">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing && e.keyCode !== 229) {
                  e.preventDefault()
                  sendMessage(input)
                }
              }}
              rows={1}
              placeholder={supported ? "Escribí o tocá el micrófono..." : "Escribí tu consulta..."}
              className="max-h-32 min-h-9 flex-1 resize-none bg-transparent py-1.5 text-sm text-foreground outline-none placeholder:text-muted-foreground"
            />
          </div>

          <button
            type="button"
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || loading}
            aria-label="Enviar"
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-secondary text-foreground transition-colors hover:bg-secondary/70 disabled:opacity-40"
          >
            <Send className="h-5 w-5" />
          </button>
        </div>
        {!supported && (
          <p className="mx-auto mt-2 max-w-2xl text-center text-xs text-muted-foreground">
            Tu navegador no soporta reconocimiento de voz. Podés escribir tus consultas.
          </p>
        )}
      </footer>
    </div>
  )
}

function MessageBubble({ role, content }: { role: "user" | "assistant"; content: string }) {
  const isUser = role === "user"
  return (
    <div
      className={cn(
        "max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed",
        isUser
          ? "self-end rounded-br-md bg-primary text-primary-foreground"
          : "self-start rounded-bl-md bg-card text-card-foreground",
      )}
    >
      {content}
    </div>
  )
}

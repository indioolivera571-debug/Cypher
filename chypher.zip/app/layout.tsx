import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Space_Grotesk, JetBrains_Mono } from 'next/font/google'
import './globals.css'

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-sans',
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
})

export const metadata: Metadata = {
  title: 'Chypher · Asistente Agronómico',
  description:
    'Asistente de voz para estudiantes de agronomía. Preguntá sobre suelos, cultivos, ganadería y cálculos técnicos.',
  generator: 'v0.app',
  manifest: '/manifest.json',
  applicationName: 'Chypher',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'Chypher',
  },
  icons: {
    icon: [{ url: '/icons/icon-192.png', type: 'image/png', sizes: '192x192' }],
    apple: '/icons/icon-192.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#14110D',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="es"
      className={`dark bg-background ${spaceGrotesk.variable} ${jetbrainsMono.variable}`}
    >
      <body className="antialiased font-sans">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}

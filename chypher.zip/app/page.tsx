import { ChypherAssistant } from "@/components/chypher-assistant"

export default function Page() {
  return <ChypherAssistant />
}

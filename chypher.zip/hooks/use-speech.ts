"use client"

import { useCallback, useEffect, useRef, useState } from "react"

// Minimal typings for the Web Speech API (not in standard TS lib DOM yet).
type SpeechRecognitionResultLike = {
  0: { transcript: string }
  isFinal: boolean
}
type SpeechRecognitionEventLike = {
  resultIndex: number
  results: { length: number } & Record<number, SpeechRecognitionResultLike>
}
type SpeechRecognitionLike = {
  lang: string
  continuous: boolean
  interimResults: boolean
  start: () => void
  stop: () => void
  abort: () => void
  onresult: ((e: SpeechRecognitionEventLike) => void) | null
  onerror: ((e: { error: string }) => void) | null
  onend: (() => void) | null
}

function getRecognitionCtor(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === "undefined") return null
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRecognitionLike
    webkitSpeechRecognition?: new () => SpeechRecognitionLike
  }
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null
}

export function useSpeech(lang = "es-AR") {
  const [supported, setSupported] = useState(false)
  const [listening, setListening] = useState(false)
  const [speaking, setSpeaking] = useState(false)
  const [interim, setInterim] = useState("")

  const recognitionRef = useRef<SpeechRecognitionLike | null>(null)
  const finalRef = useRef("")
  const onFinalRef = useRef<((text: string) => void) | null>(null)

  useEffect(() => {
    const Ctor = getRecognitionCtor()
    const hasSynth = typeof window !== "undefined" && "speechSynthesis" in window
    setSupported(Boolean(Ctor) && hasSynth)
    if (!Ctor) return

    const recognition = new Ctor()
    recognition.lang = lang
    recognition.continuous = false
    recognition.interimResults = true

    recognition.onresult = (event) => {
      let interimText = ""
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i]
        const transcript = result[0].transcript
        if (result.isFinal) {
          finalRef.current += transcript
        } else {
          interimText += transcript
        }
      }
      setInterim(interimText)
    }

    recognition.onerror = () => {
      setListening(false)
    }

    recognition.onend = () => {
      setListening(false)
      setInterim("")
      const text = finalRef.current.trim()
      finalRef.current = ""
      if (text && onFinalRef.current) onFinalRef.current(text)
    }

    recognitionRef.current = recognition

    return () => {
      recognition.onresult = null
      recognition.onerror = null
      recognition.onend = null
      recognition.abort()
    }
  }, [lang])

  const startListening = useCallback((onFinal: (text: string) => void) => {
    const recognition = recognitionRef.current
    if (!recognition) return
    onFinalRef.current = onFinal
    finalRef.current = ""
    setInterim("")
    try {
      recognition.start()
      setListening(true)
    } catch {
      // Already started; ignore.
    }
  }, [])

  const stopListening = useCallback(() => {
    recognitionRef.current?.stop()
  }, [])

  const speak = useCallback(
    (text: string) => {
      if (typeof window === "undefined" || !("speechSynthesis" in window)) return
      window.speechSynthesis.cancel()
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = lang
      const voices = window.speechSynthesis.getVoices()
      const esVoice = voices.find((v) => v.lang.toLowerCase().startsWith("es"))
      if (esVoice) utterance.voice = esVoice
      utterance.rate = 1.02
      utterance.pitch = 1
      utterance.onstart = () => setSpeaking(true)
      utterance.onend = () => setSpeaking(false)
      utterance.onerror = () => setSpeaking(false)
      window.speechSynthesis.speak(utterance)
    },
    [lang],
  )

  const stopSpeaking = useCallback(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return
    window.speechSynthesis.cancel()
    setSpeaking(false)
  }, [])

  return {
    supported,
    listening,
    speaking,
    interim,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
  }
}
